from controladores.controlador_sistema import ControladorSistema

ControladorSistema().inicializa_sistema()
